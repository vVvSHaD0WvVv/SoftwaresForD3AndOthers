package br.com.d3.main;

import java.awt.Color;

public class Posicao{
	public int x, y;
	public Color cor;
	
	public Posicao( int x, int y, Color cor){
		this.x = x;
		this.y = y;
		this.cor = cor;
	}
	
}