package br.com.d3.properties;

public class PropriedadesActor {
	private int guiId;
	
	private String name;
	
	private float posx;
	
	private float posy;
	
	private float posz;
	
	private int data1;
	
	private int data2;
	
	private int data3;
	
	private int distance;

	public int getGuiId() {
		return guiId;
	}

	public void setGuiId(int guiId) {
		this.guiId = guiId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPosx() {
		return posx;
	}

	public void setPosx(float posx) {
		this.posx = posx;
	}

	public float getPosy() {
		return posy;
	}

	public void setPosy(float posy) {
		this.posy = posy;
	}

	public float getPosz() {
		return posz;
	}

	public void setPosz(float posz) {
		this.posz = posz;
	}

	public int getData1() {
		return data1;
	}

	public void setData1(int data1) {
		this.data1 = data1;
	}

	public int getData2() {
		return data2;
	}

	public void setData2(int data2) {
		this.data2 = data2;
	}

	public int getData3() {
		return data3;
	}

	public void setData3(int data3) {
		this.data3 = data3;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}
	
	
}
