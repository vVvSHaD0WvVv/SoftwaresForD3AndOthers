Enigma protector v1.02

(C)Copyright Vladimir Sukhov 2004-2005
Website: http://www.enigma.xost.net/
E-mail : enigmasoft@mail.ru


Overview:

Enigma protector - software protection tool, for application protection.

Enigma protector serves for software protection of applications. It defending your work from program crackers with state-of-the-art encryption, data compression, and other security features. Enigma protector provides creation trial and registered applications, with possibility of the checking mode parameters with help internal Enigma API functions. It allows you to design and add a complete software protection and registration-key system to your existing programs. It works with any language which produce Windows PE files. Enigma works with Win PE 32 executables (*.exe), screen savers (*.scr) files.

Features
* compression & encryption of file 
* application code emulation: 
  * file entry point protection (delete original code and replace it with polimorphic instructions) 
  * import table redirection 
  * advance force import protection 
  * emulation some WinAPI functions 
  * protection data section 
* "not crack" protection: 
  * anti-debuggers (as SoftIce, OlliDbg, TWD) protection 
  * control sum (CRC) checking 
  * trash instructions 
  * anti-trasing tricks 
  * memory anti- dumping, patching 
* possibility to create trial applications 
  * trial time depend on number of executions, number of used days, until the date 
  * clock reversing control 
  * internal Enigma API for working with trial mode 
* possibility to create registered application by means registration   key(s) 
  * application keys locking 
  * time limited keys 
  * hardware locking keys 


System Requirement:
Windows 95/98/NT/2000/ME/XP


