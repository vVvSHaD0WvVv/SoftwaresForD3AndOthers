 /*API for registration*/
 extern "C" BOOL SaveKey( char* Name, char* Key );
 extern "C" BOOL LoadKey( char** Name, char** Key );
 extern "C" BOOL CheckKey( char* Name, char* Key );
 extern "C" BOOL DeleteKey();
 extern "C" BOOL LoadAndCheckKey();
 extern "C" BOOL CheckAndSaveKey( char* Name, char* Key );
 extern "C" char* GetHardwareID();
 /*API for trial*/
 extern "C" BOOL GetNumberOfExecutions( DWORD* Total, DWORD* Left );
 extern "C" BOOL GetNumberOfDays( DWORD* Total, DWORD* Left );
 extern "C" BOOL GetExpirationDate( WORD* Year, WORD* Month, WORD* Day );
