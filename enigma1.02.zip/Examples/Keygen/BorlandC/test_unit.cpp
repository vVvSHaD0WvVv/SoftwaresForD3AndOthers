//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "test_unit.h"
#include "include/enigma_keygen.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

  EGenerateRegistrationKey fnGenerateRegistrationKey = NULL;
  EGenerateRegistrationKeyFromProject fnGenerateRegistrationKeyFromProject = NULL;
  HINSTANCE LibHandle;
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
  LibHandle = LoadLibrary("keygen.dll");
  fnGenerateRegistrationKey = (EGenerateRegistrationKey)GetProcAddress(LibHandle, "GenerateRegistrationKey");
  fnGenerateRegistrationKeyFromProject = (EGenerateRegistrationKeyFromProject)GetProcAddress(LibHandle, "GenerateRegistrationKeyFromProject");
  if (fnGenerateRegistrationKey == NULL || fnGenerateRegistrationKeyFromProject == NULL)
  {
    btnGK->Enabled = false;
    btnGKFPF->Enabled = false;
  }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnCloseClick(TObject *Sender)
{
  ExitProcess(0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnGKClick(TObject *Sender)
{
 PKeyParams kp;
 _KeyParams tempkp;

 char keybuf[255];

 kp = &tempkp;
 memset(kp, 0 , sizeof(_KeyParams));

 memset(&keybuf, 0 , 255);

 kp->KeyLen = 255;  // Key buffer length
 kp->Key = keybuf;  // Key buffer

 kp->UserInfo = eUserInfo->Text.c_str(); // Offset to UserInfo
 kp->UserInfoLen = strlen(kp->UserInfo); // UserInfo length

 kp->HardwareID = eHardware->Text.c_str(); // Offset to HardwareID

 kp->ExrirationYear = 2006; // Expiration year
 kp->ExpirationMonth = 1;   // Expiration month
 kp->ExpirationDay = 1;     // Expiration day

 // Get it from project file --------------------------------------------------
 kp->Encode = 0xEFA226FF;
 kp->key1 = "8227922596A67820EB3770384075F19778D3BA526AA5FDE3E5864B8BCF17340A";
 kp->key2 = "5D4AC1AFB6C12DC48CF59EBD7423B6C10A392E723448ECFF07293DEF1A5B1935";
 kp->key3 = "5B57A767ACCB6746D383AFDA91FB63CFDDD024EBA18C4AB7789463B93E292DDB";
 kp->key4 = "7EB51AD506F0E7C5368DE33CCC64D5723D6EAE69E9EF6F2BB7A9FB76DAF7A96E";
 kp->key5 = "DA2AE34728821FE0BEA4F1CFAC671C5B884DCD5B1B156B00D829B3F4DEE3F563";
 kp->key6 = "98E3BECE49F537C00A3E04C70FB27E43310C79F517C4FE5E83BBAF4A93AAB234";
 kp->key7 = "F6715D4075E20A0E4CB5B899249772E3BFAE9D2E92E69EEFF4EC89D092B2B15C";
 // ---------------------------------------------------------------------------

 fnGenerateRegistrationKey(kp); // Key generation function

 eKey->Text = kp->Key;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::btnGKFPFClick(TObject *Sender)
{
 PKeyParams kp;
 _KeyParams tempkp;

 char* ProjectFileName;

 char* GenResult;
 char keybuf[255];

 kp = &tempkp;
 memset(kp, 0 , sizeof(_KeyParams));

 memset(&keybuf, 0 , 255);

 kp->KeyLen = 255;  // Key buffer length
 kp->Key = keybuf;  // Key buffer

 kp->UserInfo = eUserInfo->Text.c_str(); // Offset to UserInfo
 kp->UserInfoLen = strlen(kp->UserInfo); // UserInfo length
 kp->HardwareID = eHardware->Text.c_str(); // Offset to HardwareID

 kp->ExrirationYear = 2006; // Expiration year
 kp->ExpirationMonth = 1;   // Expiration month
 kp->ExpirationDay = 1;     // Expiration day

 ProjectFileName = AnsiString(ExtractFilePath(ParamStr(0)) + "enigma_test.ini").c_str();

 // Key generation function
 GenResult = fnGenerateRegistrationKeyFromProject(ProjectFileName, kp);
 if (GenResult == NULL)
   {eKey->Text = kp->Key;} else {eKey->Text = GenResult;}
}
//---------------------------------------------------------------------------

