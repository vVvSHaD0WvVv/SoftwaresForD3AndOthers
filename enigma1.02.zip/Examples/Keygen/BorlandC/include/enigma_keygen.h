/* This file include to Enigma protector distributive.
Do NOT remove it!*/

typedef struct _KeyParams
{
  char* Key;
  DWORD KeyLen;
  char* UserInfo;
  DWORD UserInfoLen;
  WORD ExrirationYear;
  BYTE ExpirationMonth;
  BYTE ExpirationDay;
  char* HardwareID;
  DWORD Encode;
  char* key1;
  char* key2;
  char* key3;
  char* key4;
  char* key5;
  char* key6;
  char* key7;
} KeyParams, *PKeyParams;

#define GenerateRegistrationKey		_T("GenerateRegistrationKey")
#define GenerateRegistrationKeyFromProject _T("GenerateRegistrationKeyFromProject")

typedef char* (__stdcall *EGenerateRegistrationKey)(IN OUT KeyParams *kp);
typedef char* (__stdcall *EGenerateRegistrationKeyFromProject)(IN LPTSTR ProjectFileName, IN OUT KeyParams *kp);

