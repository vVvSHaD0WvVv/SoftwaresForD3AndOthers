//---------------------------------------------------------------------------

#ifndef test_unitH
#define test_unitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *btnGK;
        TButton *btnGKFPF;
        TEdit *eHardware;
        TLabel *lbHardware;
        TLabel *lbUserInfo;
        TEdit *eUserInfo;
        TLabel *lbKey;
        TEdit *eKey;
        TBevel *Bevel1;
        TButton *btnClose;
        void __fastcall btnCloseClick(TObject *Sender);
        void __fastcall btnGKClick(TObject *Sender);
        void __fastcall btnGKFPFClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
