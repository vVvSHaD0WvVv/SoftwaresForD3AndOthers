using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enigma.D3.Enums
{
	public enum GemType
	{
		Amethyst = 1,
		Emerald = 2,
		Ruby = 3,
		Topaz = 4,
		Diamond = 5
	}
}
