using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enigma.D3.Enums
{
	public enum FollowerType
	{
		None = 0,
		Templar = 1,
		Scoundrel = 2,
		Enchantress = 3
	}
}
