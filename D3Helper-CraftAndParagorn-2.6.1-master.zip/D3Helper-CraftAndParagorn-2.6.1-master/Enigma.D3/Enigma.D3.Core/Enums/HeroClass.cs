using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enigma.D3.Enums
{
    public enum HeroClass
    {
        None = -1,
        DemonHunter = 0,
        Barbarian = 1,
        Wizard = 2,
        Witchdoctor = 3,
        Monk = 4,
        Crusader = 5,
        Necromancer = 6
    }
}
