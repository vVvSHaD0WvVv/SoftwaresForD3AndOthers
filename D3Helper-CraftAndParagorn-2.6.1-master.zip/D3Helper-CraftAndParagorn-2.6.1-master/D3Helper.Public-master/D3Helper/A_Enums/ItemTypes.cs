﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D3Helper.A_Enums
{
    public enum ItemTypes
    {
        Other = -1,
        _1HWeapon = 0,
        _2HWeapon = 1,
        Armor = 2,
        Amulet = 3,
        Ring = 4
        
    }
}
