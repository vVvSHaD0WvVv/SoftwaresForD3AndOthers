﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D3Helper.A_Enums
{
    public enum ActionBarSlot
    {
        Slot1 = 0,
        Slot2 = 1,
        Slot3 = 2,
        Slot4 = 3,
        LMB = 4,
        RMB = 5,
        Potion = 6,
    }
}
