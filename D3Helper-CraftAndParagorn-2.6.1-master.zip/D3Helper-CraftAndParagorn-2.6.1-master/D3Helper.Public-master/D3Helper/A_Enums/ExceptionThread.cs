﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D3Helper.A_Enums
{
    public enum ExceptionThread
    {
        MainWindow = -1,
        ICollector = 0,
        ECollector = 1,
        Handler = 2,
        HotkeyProcessor = 3,
        Overlay = 4,
    }
}
