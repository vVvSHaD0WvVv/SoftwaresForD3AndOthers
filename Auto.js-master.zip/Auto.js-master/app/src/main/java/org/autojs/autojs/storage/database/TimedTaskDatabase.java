package org.autojs.autojs.storage.database;

import com.raizlabs.android.dbflow.annotation.Database;

/**
 * Created by Stardust on 2017/11/28.
 */
@Database(version = 1)
public class TimedTaskDatabase {
}
