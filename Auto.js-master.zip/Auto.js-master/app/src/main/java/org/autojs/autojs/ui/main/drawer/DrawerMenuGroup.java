package org.autojs.autojs.ui.main.drawer;

/**
 * Created by Stardust on 2017/8/25.
 */

public class DrawerMenuGroup extends DrawerMenuItem {

    public DrawerMenuGroup(int title) {
        super(0, title, null);
    }

}
