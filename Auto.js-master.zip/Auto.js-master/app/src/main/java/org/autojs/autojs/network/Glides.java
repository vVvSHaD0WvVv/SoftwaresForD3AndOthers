package org.autojs.autojs.network;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by Stardust on 2017/10/26.
 */
@GlideModule
public class Glides extends AppGlideModule {
}
