log("Hello world!!!");
toast("Hello, AutoJs!");
console.show();