"auto";

setScreenMetrics(1080, 1920);

click(100, 150);