module.exports = function(runtime, global){
    return Object.create(runtime.media);
}