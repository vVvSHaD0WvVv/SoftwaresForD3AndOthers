﻿using System;

namespace Rss
{
	// Token: 0x02000093 RID: 147
	[Serializable]
	public enum RssCloudProtocol
	{
		// Token: 0x04000328 RID: 808
		Empty,
		// Token: 0x04000329 RID: 809
		NotSupported,
		// Token: 0x0400032A RID: 810
		XmlRpc,
		// Token: 0x0400032B RID: 811
		Soap,
		// Token: 0x0400032C RID: 812
		HttpPost
	}
}
