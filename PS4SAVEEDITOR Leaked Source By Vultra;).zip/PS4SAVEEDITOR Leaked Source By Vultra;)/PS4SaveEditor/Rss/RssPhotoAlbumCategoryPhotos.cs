﻿using System;

namespace Rss
{
	// Token: 0x02000086 RID: 134
	public sealed class RssPhotoAlbumCategoryPhotos : RssModuleItemCollectionCollection
	{
		// Token: 0x0600067E RID: 1662 RVA: 0x000238FC File Offset: 0x00021AFC
		public int Add(RssPhotoAlbumCategoryPhoto photo)
		{
			return base.Add(photo);
		}
	}
}
