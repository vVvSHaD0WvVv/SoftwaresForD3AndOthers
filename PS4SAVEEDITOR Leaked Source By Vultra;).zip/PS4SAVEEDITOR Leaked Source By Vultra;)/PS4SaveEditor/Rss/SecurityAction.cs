﻿using System;

namespace Rss
{
	// Token: 0x02000091 RID: 145
	internal enum SecurityAction
	{
		// Token: 0x04000322 RID: 802
		RequestMinimum
	}
}
