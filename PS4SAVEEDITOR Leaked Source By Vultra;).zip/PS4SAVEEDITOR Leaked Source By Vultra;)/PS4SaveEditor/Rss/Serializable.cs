﻿using System;

namespace Rss
{
	// Token: 0x0200008F RID: 143
	internal class Serializable : Attribute
	{
	}
}
