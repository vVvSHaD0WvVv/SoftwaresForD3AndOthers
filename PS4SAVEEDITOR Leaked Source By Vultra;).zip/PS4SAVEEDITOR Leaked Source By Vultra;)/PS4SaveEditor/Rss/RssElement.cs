﻿using System;

namespace Rss
{
	// Token: 0x02000077 RID: 119
	[Serializable]
	public abstract class RssElement
	{
	}
}
