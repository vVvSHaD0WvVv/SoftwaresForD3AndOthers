﻿using System;

namespace Rss
{
	// Token: 0x02000088 RID: 136
	public sealed class RssPhotoAlbumCategories : RssModuleItemCollectionCollection
	{
		// Token: 0x06000688 RID: 1672 RVA: 0x00023A73 File Offset: 0x00021C73
		public int Add(RssPhotoAlbumCategory category)
		{
			return base.Add(category);
		}
	}
}
