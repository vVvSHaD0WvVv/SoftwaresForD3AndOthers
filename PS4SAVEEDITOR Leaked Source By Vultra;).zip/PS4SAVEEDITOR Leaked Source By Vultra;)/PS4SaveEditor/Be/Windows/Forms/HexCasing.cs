﻿using System;

namespace Be.Windows.Forms
{
	// Token: 0x02000057 RID: 87
	public enum HexCasing
	{
		// Token: 0x0400021C RID: 540
		Upper,
		// Token: 0x0400021D RID: 541
		Lower
	}
}
