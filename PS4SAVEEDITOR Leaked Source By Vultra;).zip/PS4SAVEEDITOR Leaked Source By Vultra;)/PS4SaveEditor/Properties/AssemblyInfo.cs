﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.6264.22489")]
[assembly: NeutralResourcesLanguage("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("PS4SaveEditor")]
[assembly: ComVisible(false)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: Guid("e4d8486b-c87c-4e72-94f7-807f9088ebd3")]
[assembly: AssemblyCompany("CYBER Gadget")]
[assembly: AssemblyProduct("PS4SaveEditor")]
[assembly: AssemblyCopyright("Copyright © CYBER Gadget. All rights reserved.")]
[assembly: AssemblyTrademark("")]
