﻿using System;

namespace PS3SaveEditor
{
	// Token: 0x0200000C RID: 12
	public class region
	{
		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600006B RID: 107 RVA: 0x00007647 File Offset: 0x00005847
		// (set) Token: 0x0600006C RID: 108 RVA: 0x0000764F File Offset: 0x0000584F
		public int id
		{
			get;
			set;
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600006D RID: 109 RVA: 0x00007658 File Offset: 0x00005858
		// (set) Token: 0x0600006E RID: 110 RVA: 0x00007660 File Offset: 0x00005860
		public string code
		{
			get;
			set;
		}
	}
}
