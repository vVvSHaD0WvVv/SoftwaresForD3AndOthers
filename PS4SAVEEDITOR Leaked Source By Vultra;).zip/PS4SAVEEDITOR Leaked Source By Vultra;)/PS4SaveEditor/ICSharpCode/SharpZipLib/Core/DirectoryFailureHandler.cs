﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000AC RID: 172
	// (Invoke) Token: 0x0600078E RID: 1934
	public delegate void DirectoryFailureHandler(object sender, ScanFailureEventArgs e);
}
