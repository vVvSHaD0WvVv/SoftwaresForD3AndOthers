﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000A9 RID: 169
	// (Invoke) Token: 0x06000782 RID: 1922
	public delegate void ProcessFileHandler(object sender, ScanEventArgs e);
}
