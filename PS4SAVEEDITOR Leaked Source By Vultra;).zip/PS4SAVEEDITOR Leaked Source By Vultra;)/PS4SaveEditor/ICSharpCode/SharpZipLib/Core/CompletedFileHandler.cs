﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000AB RID: 171
	// (Invoke) Token: 0x0600078A RID: 1930
	public delegate void CompletedFileHandler(object sender, ScanEventArgs e);
}
