﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000AD RID: 173
	// (Invoke) Token: 0x06000792 RID: 1938
	public delegate void FileFailureHandler(object sender, ScanFailureEventArgs e);
}
