﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000AA RID: 170
	// (Invoke) Token: 0x06000786 RID: 1926
	public delegate void ProgressHandler(object sender, ProgressEventArgs e);
}
