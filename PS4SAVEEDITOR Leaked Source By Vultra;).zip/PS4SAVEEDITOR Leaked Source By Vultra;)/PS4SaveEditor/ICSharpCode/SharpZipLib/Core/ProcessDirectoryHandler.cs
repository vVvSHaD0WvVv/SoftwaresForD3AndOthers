﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000A8 RID: 168
	// (Invoke) Token: 0x0600077E RID: 1918
	public delegate void ProcessDirectoryHandler(object sender, DirectoryEventArgs e);
}
