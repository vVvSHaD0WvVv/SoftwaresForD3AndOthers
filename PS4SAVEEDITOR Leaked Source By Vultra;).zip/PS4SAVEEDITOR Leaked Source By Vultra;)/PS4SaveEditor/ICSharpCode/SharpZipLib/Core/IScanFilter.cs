﻿using System;

namespace ICSharpCode.SharpZipLib.Core
{
	// Token: 0x020000B0 RID: 176
	public interface IScanFilter
	{
		// Token: 0x060007A2 RID: 1954
		bool IsMatch(string name);
	}
}
