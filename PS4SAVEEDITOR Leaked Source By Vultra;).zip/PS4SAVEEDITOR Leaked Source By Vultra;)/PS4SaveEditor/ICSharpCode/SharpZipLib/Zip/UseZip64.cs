﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000D5 RID: 213
	public enum UseZip64
	{
		// Token: 0x0400048C RID: 1164
		Off,
		// Token: 0x0400048D RID: 1165
		On,
		// Token: 0x0400048E RID: 1166
		Dynamic
	}
}
