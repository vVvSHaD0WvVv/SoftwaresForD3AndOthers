﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000EC RID: 236
	public enum FileUpdateMode
	{
		// Token: 0x0400053B RID: 1339
		Safe,
		// Token: 0x0400053C RID: 1340
		Direct
	}
}
