﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000E9 RID: 233
	public enum TestOperation
	{
		// Token: 0x0400052E RID: 1326
		Initialising,
		// Token: 0x0400052F RID: 1327
		EntryHeader,
		// Token: 0x04000530 RID: 1328
		EntryData,
		// Token: 0x04000531 RID: 1329
		EntryComplete,
		// Token: 0x04000532 RID: 1330
		MiscellaneousTests,
		// Token: 0x04000533 RID: 1331
		Complete
	}
}
