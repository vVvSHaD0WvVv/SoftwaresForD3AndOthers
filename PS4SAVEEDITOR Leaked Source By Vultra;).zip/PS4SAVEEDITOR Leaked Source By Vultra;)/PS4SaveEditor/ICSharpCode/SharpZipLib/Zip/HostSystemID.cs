﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000DA RID: 218
	public enum HostSystemID
	{
		// Token: 0x040004D9 RID: 1241
		Msdos,
		// Token: 0x040004DA RID: 1242
		Amiga,
		// Token: 0x040004DB RID: 1243
		OpenVms,
		// Token: 0x040004DC RID: 1244
		Unix,
		// Token: 0x040004DD RID: 1245
		VMCms,
		// Token: 0x040004DE RID: 1246
		AtariST,
		// Token: 0x040004DF RID: 1247
		OS2,
		// Token: 0x040004E0 RID: 1248
		Macintosh,
		// Token: 0x040004E1 RID: 1249
		ZSystem,
		// Token: 0x040004E2 RID: 1250
		Cpm,
		// Token: 0x040004E3 RID: 1251
		WindowsNT,
		// Token: 0x040004E4 RID: 1252
		MVS,
		// Token: 0x040004E5 RID: 1253
		Vse,
		// Token: 0x040004E6 RID: 1254
		AcornRisc,
		// Token: 0x040004E7 RID: 1255
		Vfat,
		// Token: 0x040004E8 RID: 1256
		AlternateMvs,
		// Token: 0x040004E9 RID: 1257
		BeOS,
		// Token: 0x040004EA RID: 1258
		Tandem,
		// Token: 0x040004EB RID: 1259
		OS400,
		// Token: 0x040004EC RID: 1260
		OSX,
		// Token: 0x040004ED RID: 1261
		WinZipAES = 99
	}
}
