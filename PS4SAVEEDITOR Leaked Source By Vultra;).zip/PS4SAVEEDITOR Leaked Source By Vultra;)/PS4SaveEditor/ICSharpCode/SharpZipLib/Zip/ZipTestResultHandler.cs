﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000EB RID: 235
	// (Invoke) Token: 0x060009B5 RID: 2485
	public delegate void ZipTestResultHandler(TestStatus status, string message);
}
