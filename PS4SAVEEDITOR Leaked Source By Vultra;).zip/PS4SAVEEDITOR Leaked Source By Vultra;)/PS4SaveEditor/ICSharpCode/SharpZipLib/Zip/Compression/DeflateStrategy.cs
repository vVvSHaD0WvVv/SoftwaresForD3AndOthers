﻿using System;

namespace ICSharpCode.SharpZipLib.Zip.Compression
{
	// Token: 0x020000C1 RID: 193
	public enum DeflateStrategy
	{
		// Token: 0x040003D2 RID: 978
		Default,
		// Token: 0x040003D3 RID: 979
		Filtered,
		// Token: 0x040003D4 RID: 980
		HuffmanOnly
	}
}
