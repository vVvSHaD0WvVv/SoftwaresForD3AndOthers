﻿using System;

namespace ICSharpCode.SharpZipLib.Zip.Compression
{
	// Token: 0x020000C6 RID: 198
	public class DeflaterPending : PendingBuffer
	{
		// Token: 0x0600084B RID: 2123 RVA: 0x00030215 File Offset: 0x0002E415
		public DeflaterPending() : base(65536)
		{
		}
	}
}
