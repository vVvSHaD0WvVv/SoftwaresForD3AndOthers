﻿using System;
using System.IO;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000F7 RID: 247
	public interface IStaticDataSource
	{
		// Token: 0x06000A5D RID: 2653
		Stream GetSource();
	}
}
