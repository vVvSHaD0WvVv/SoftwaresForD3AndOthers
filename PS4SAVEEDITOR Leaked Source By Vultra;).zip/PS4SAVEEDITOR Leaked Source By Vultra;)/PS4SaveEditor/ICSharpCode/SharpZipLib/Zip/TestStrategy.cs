﻿using System;

namespace ICSharpCode.SharpZipLib.Zip
{
	// Token: 0x020000E8 RID: 232
	public enum TestStrategy
	{
		// Token: 0x0400052B RID: 1323
		FindFirstError,
		// Token: 0x0400052C RID: 1324
		FindAllErrors
	}
}
