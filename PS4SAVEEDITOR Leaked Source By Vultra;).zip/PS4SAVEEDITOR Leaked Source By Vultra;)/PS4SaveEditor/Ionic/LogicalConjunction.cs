﻿using System;

namespace Ionic
{
	// Token: 0x0200012D RID: 301
	internal enum LogicalConjunction
	{
		// Token: 0x0400065C RID: 1628
		NONE,
		// Token: 0x0400065D RID: 1629
		AND,
		// Token: 0x0400065E RID: 1630
		OR,
		// Token: 0x0400065F RID: 1631
		XOR
	}
}
