﻿using System;

namespace Ionic
{
	// Token: 0x0200012E RID: 302
	internal enum WhichTime
	{
		// Token: 0x04000661 RID: 1633
		atime,
		// Token: 0x04000662 RID: 1634
		mtime,
		// Token: 0x04000663 RID: 1635
		ctime
	}
}
