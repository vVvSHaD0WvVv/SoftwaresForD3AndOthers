﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000164 RID: 356
	public enum CompressionLevel
	{
		// Token: 0x04000875 RID: 2165
		None,
		// Token: 0x04000876 RID: 2166
		Level0 = 0,
		// Token: 0x04000877 RID: 2167
		BestSpeed,
		// Token: 0x04000878 RID: 2168
		Level1 = 1,
		// Token: 0x04000879 RID: 2169
		Level2,
		// Token: 0x0400087A RID: 2170
		Level3,
		// Token: 0x0400087B RID: 2171
		Level4,
		// Token: 0x0400087C RID: 2172
		Level5,
		// Token: 0x0400087D RID: 2173
		Default,
		// Token: 0x0400087E RID: 2174
		Level6 = 6,
		// Token: 0x0400087F RID: 2175
		Level7,
		// Token: 0x04000880 RID: 2176
		Level8,
		// Token: 0x04000881 RID: 2177
		BestCompression,
		// Token: 0x04000882 RID: 2178
		Level9 = 9
	}
}
