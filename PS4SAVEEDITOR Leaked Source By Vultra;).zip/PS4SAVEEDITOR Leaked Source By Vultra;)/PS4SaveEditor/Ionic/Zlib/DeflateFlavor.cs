﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000115 RID: 277
	internal enum DeflateFlavor
	{
		// Token: 0x040005D8 RID: 1496
		Store,
		// Token: 0x040005D9 RID: 1497
		Fast,
		// Token: 0x040005DA RID: 1498
		Slow
	}
}
