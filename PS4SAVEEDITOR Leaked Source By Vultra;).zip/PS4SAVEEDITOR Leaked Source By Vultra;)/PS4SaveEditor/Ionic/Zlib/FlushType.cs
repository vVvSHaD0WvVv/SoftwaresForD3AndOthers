﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000163 RID: 355
	public enum FlushType
	{
		// Token: 0x0400086F RID: 2159
		None,
		// Token: 0x04000870 RID: 2160
		Partial,
		// Token: 0x04000871 RID: 2161
		Sync,
		// Token: 0x04000872 RID: 2162
		Full,
		// Token: 0x04000873 RID: 2163
		Finish
	}
}
