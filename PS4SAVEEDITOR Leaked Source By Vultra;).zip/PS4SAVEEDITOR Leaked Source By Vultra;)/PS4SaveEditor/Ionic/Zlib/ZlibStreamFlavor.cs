﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200016C RID: 364
	internal enum ZlibStreamFlavor
	{
		// Token: 0x040008A1 RID: 2209
		ZLIB = 1950,
		// Token: 0x040008A2 RID: 2210
		DEFLATE,
		// Token: 0x040008A3 RID: 2211
		GZIP
	}
}
