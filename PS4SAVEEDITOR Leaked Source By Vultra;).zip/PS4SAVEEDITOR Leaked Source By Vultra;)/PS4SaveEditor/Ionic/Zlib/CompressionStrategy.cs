﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000165 RID: 357
	public enum CompressionStrategy
	{
		// Token: 0x04000884 RID: 2180
		Default,
		// Token: 0x04000885 RID: 2181
		Filtered,
		// Token: 0x04000886 RID: 2182
		HuffmanOnly
	}
}
