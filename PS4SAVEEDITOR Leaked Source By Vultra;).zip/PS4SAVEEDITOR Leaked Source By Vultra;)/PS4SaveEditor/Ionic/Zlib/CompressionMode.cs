﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000166 RID: 358
	public enum CompressionMode
	{
		// Token: 0x04000888 RID: 2184
		Compress,
		// Token: 0x04000889 RID: 2185
		Decompress
	}
}
