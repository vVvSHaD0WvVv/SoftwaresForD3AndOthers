﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000114 RID: 276
	internal enum BlockState
	{
		// Token: 0x040005D3 RID: 1491
		NeedMore,
		// Token: 0x040005D4 RID: 1492
		BlockDone,
		// Token: 0x040005D5 RID: 1493
		FinishStarted,
		// Token: 0x040005D6 RID: 1494
		FinishDone
	}
}
