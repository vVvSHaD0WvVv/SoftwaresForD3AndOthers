﻿using System;

namespace Ionic.Zip
{
	// Token: 0x0200015C RID: 348
	public enum SelfExtractorFlavor
	{
		// Token: 0x0400081E RID: 2078
		ConsoleApplication,
		// Token: 0x0400081F RID: 2079
		WinFormsApplication
	}
}
