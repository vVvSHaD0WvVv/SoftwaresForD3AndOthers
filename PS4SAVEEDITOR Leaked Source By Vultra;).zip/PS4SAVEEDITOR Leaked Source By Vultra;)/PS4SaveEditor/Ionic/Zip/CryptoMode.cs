﻿using System;

namespace Ionic.Zip
{
	// Token: 0x0200014C RID: 332
	internal enum CryptoMode
	{
		// Token: 0x0400075D RID: 1885
		Encrypt,
		// Token: 0x0400075E RID: 1886
		Decrypt
	}
}
