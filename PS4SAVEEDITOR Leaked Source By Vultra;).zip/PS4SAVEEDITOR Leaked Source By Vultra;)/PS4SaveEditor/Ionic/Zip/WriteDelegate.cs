﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x0200011B RID: 283
	// (Invoke) Token: 0x06000BE3 RID: 3043
	public delegate void WriteDelegate(string entryName, Stream stream);
}
