﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x0200011C RID: 284
	// (Invoke) Token: 0x06000BE7 RID: 3047
	public delegate Stream OpenDelegate(string entryName);
}
