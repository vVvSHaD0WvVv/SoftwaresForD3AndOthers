﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x0200011D RID: 285
	// (Invoke) Token: 0x06000BEB RID: 3051
	public delegate void CloseDelegate(string entryName, Stream stream);
}
