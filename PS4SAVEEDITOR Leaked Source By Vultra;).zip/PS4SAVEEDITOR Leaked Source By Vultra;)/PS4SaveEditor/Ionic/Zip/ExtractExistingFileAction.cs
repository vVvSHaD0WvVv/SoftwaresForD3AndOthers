﻿using System;

namespace Ionic.Zip
{
	// Token: 0x0200012C RID: 300
	public enum ExtractExistingFileAction
	{
		// Token: 0x04000657 RID: 1623
		Throw,
		// Token: 0x04000658 RID: 1624
		OverwriteSilently,
		// Token: 0x04000659 RID: 1625
		DoNotOverwrite,
		// Token: 0x0400065A RID: 1626
		InvokeExtractProgressEvent
	}
}
