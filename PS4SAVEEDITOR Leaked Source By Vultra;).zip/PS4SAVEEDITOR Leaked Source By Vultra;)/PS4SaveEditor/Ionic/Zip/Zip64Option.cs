﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000157 RID: 343
	public enum Zip64Option
	{
		// Token: 0x0400080E RID: 2062
		Default,
		// Token: 0x0400080F RID: 2063
		Never = 0,
		// Token: 0x04000810 RID: 2064
		AsNecessary,
		// Token: 0x04000811 RID: 2065
		Always
	}
}
