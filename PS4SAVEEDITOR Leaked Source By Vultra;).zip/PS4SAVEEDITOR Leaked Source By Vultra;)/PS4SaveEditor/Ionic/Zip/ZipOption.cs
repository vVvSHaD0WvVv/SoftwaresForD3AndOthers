﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000158 RID: 344
	public enum ZipOption
	{
		// Token: 0x04000813 RID: 2067
		Default,
		// Token: 0x04000814 RID: 2068
		Never = 0,
		// Token: 0x04000815 RID: 2069
		AsNecessary,
		// Token: 0x04000816 RID: 2070
		Always
	}
}
