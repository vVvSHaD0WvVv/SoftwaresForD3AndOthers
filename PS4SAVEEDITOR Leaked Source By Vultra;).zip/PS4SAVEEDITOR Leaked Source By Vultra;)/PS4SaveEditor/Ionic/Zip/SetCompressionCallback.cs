﻿using System;
using Ionic.Zlib;

namespace Ionic.Zip
{
	// Token: 0x0200011E RID: 286
	// (Invoke) Token: 0x06000BEF RID: 3055
	public delegate CompressionLevel SetCompressionCallback(string localFileName, string fileNameInArchive);
}
