﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000159 RID: 345
	internal enum AddOrUpdateAction
	{
		// Token: 0x04000818 RID: 2072
		AddOnly,
		// Token: 0x04000819 RID: 2073
		AddOrUpdate
	}
}
