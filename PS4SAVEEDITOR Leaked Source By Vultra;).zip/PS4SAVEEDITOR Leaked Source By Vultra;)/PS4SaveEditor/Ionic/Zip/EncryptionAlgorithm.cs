﻿using System;

namespace Ionic.Zip
{
	// Token: 0x0200011A RID: 282
	public enum EncryptionAlgorithm
	{
		// Token: 0x0400062F RID: 1583
		None,
		// Token: 0x04000630 RID: 1584
		PkzipWeak,
		// Token: 0x04000631 RID: 1585
		Unsupported = 4
	}
}
