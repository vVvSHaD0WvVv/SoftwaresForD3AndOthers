﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000152 RID: 338
	public enum CompressionMethod
	{
		// Token: 0x040007BB RID: 1979
		None,
		// Token: 0x040007BC RID: 1980
		Deflate = 8
	}
}
