# PS4DecryptSaveDataKey

Working code based on the wiki code:

http://www.psdevwiki.com/ps4/Sealedkey_/_pfsSKKey

Put the encrypted PFS key you want to decrypt in your first USB drive and name it pfskeyencrypted

This payload spits out a decryptedSaveDataKey.bin file on your USB
