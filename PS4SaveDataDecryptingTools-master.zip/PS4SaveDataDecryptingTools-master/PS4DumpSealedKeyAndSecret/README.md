# PS4DumpSealedKeyAndSecret

Just dumps to USB the sealed key and secret as shown here:

http://www.psdevwiki.com/ps4/Keys#Sealed_Key_Values
