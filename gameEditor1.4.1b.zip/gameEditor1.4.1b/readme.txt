Welcome to Game Editor 1.4.1b



---------------------------------------------------------------------------
Windows:

In order to execute Game Editor, just click on the gameEditor.exe file.

---------------------------------------------------------------------------
Linux:

In order to execute Game Editor on Linux type (from a terminal window):
chmod +x gameEditor
./gameEditorLinux 


---------------------------------------------------------------------------
More info:

http://game-editor.com

Thanks,
Makslane


