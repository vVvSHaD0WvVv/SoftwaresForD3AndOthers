# Dev.D3
A Memory Based Diablo3 Bot

### Credits:
* DarthTon for the public framework which helped when getting started with all of this.
* enigma32 for Enigma.D3 framework and a lot of work reversing D3.
* CrEEzz for Nav.3D great navigation system based on NavMesh.


# Offsets Version(2, 3, 0, 33567)

public static readonly Version SupportedVersion = new Version(2, 3, 0, 33567);

			public const int SnoGroupInitializers = 0x01B71ABC - 4;
			public const int SnoGroupByCode = 0x01DCD048;
			public const int SnoGroups = 0x01DCD164;
			public const int SnoGroupSearch = 0x01E2021C;
			public const int SnoFilesAsync = 0x01E20220;
			public const int ObjectManager = 0x01DCF24C;
			public const int ObjectManagerPristine = 0x01DCF250;
			public const int MessageDescriptor = 0x01E8386C;
			public const int MapActId = 0x01BBB348;
			public const int LocalData = 0x01DD04F0;
			public const int LevelArea = 0x01D27778;
			public const int LevelAreaName = 0x01D277A8;
			public const int GameplayPreferences = 0x01BA1F94;
			public const int ContainerManager = 0x01E8456C;
			public const int BuffManager = 0x01DB4990;
			public const int ApplicationLoopCount = 0x01DCF2C0;
			public const int AttributeDescriptors = 0x01B76AC8;
			public const int VideoPreferences = 0x01BA1A50;
			public const int ChatPreferences = 0x01BA2024;
			public const int SoundPreferences = 0x01BA1AE4;
			public const int SocialPreferences = 0x01BA1FF4;
			public const int UIHandlers = 0x01B684D0;
			public const int UIReferences = 0x01BBB8F8;
			public const int SnoIdToEntityId = 0x00000000;
			public const int TrickleManager = 0x01D8BF88;
			public const int PtrSnoFiles = 0x01DD1610;
