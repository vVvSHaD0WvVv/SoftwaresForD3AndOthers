﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dev.D3.Statistic
{
    public class StatisticItens
    {

        public int x000_Id { get; set; }

        public Enigma.D3.Enums.ItemQuality ItemQuality { get; set; }

    }
}
