﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Dev.D3.Core.Util
{
    public class DirectXUtil
    {

        private void DXOverlay()
        {


            //using (Texture2D texture = Texture2D.FromSwapChain(swapChain, 0))
            //{
            //    if (_lastFrame != null)
            //    {
            //        FontDescription fd = new SlimDX.Direct3D10.FontDescription()
            //        {
            //            Height = 16,
            //            FaceName = "Times New Roman",
            //            IsItalic = false,
            //            Width = 0,
            //            MipLevels = 1,
            //            CharacterSet = SlimDX.Direct3D10.FontCharacterSet.Default,
            //            Precision = SlimDX.Direct3D10.FontPrecision.Default,
            //            Quality = SlimDX.Direct3D10.FontQuality.Antialiased,
            //            PitchAndFamily = FontPitchAndFamily.Default | FontPitchAndFamily.DontCare
            //        };

            //        using (Font font = new Font(texture.Device, fd))
            //        {
            //            DrawText(font, new Vector2(100, 100), String.Format("{0}", DateTime.Now), new Color4(System.Drawing.Color.Red));
            //        }
            //    }
            //    _lastFrame = DateTime.Now;
            //}

        }
    }
}
