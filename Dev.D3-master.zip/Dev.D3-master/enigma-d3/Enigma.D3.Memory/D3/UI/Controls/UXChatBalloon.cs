using Enigma.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enigma.D3.UI.Controls
{
	public class UXChatBalloon : UXLabel
	{
		public new const int SizeOf = 0xB78; //2936
		public new const int VTable = 0x01826C88;
	}
}
