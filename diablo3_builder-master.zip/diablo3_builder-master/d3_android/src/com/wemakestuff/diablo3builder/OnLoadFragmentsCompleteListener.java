
package com.wemakestuff.diablo3builder;

public class OnLoadFragmentsCompleteListener
{

    public void OnLoadFragmentsComplete(String className)
    {

    }
}
