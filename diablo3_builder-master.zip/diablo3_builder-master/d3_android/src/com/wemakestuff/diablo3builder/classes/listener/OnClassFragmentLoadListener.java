package com.wemakestuff.diablo3builder.classes.listener;

import com.wemakestuff.diablo3builder.ClassListFragment;


public abstract class OnClassFragmentLoadListener
{
    public abstract void onClassFragmentLoaded(ClassListFragment frag);
}
