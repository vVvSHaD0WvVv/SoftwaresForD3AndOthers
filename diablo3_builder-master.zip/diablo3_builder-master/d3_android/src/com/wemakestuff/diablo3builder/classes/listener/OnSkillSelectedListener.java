package com.wemakestuff.diablo3builder.classes.listener;

import com.wemakestuff.diablo3builder.model.Skill;


public abstract class OnSkillSelectedListener
{
    public abstract void onSkillSelected(Skill s);
}
