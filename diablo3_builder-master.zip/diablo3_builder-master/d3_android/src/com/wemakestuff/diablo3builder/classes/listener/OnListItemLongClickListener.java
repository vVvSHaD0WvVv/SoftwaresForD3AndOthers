
package com.wemakestuff.diablo3builder.classes.listener;

public abstract class OnListItemLongClickListener
{

    public abstract void onListItemLongClick(int position, String title);
    public abstract void onListItemLongClickCancel();
}
