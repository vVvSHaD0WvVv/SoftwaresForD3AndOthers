
package com.wemakestuff.diablo3builder.classes.interfaces;

import com.wemakestuff.diablo3builder.classes.ClassListFragment;

public interface OnClassFragmentLoadedInterface
{
    public void onClassFragmentLoaded(ClassListFragment fragment);
}
