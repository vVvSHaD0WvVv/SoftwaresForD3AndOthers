class Item < ActiveRecord::Base
  # Remember to create a migration!
end
