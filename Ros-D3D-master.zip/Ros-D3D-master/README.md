# Ros-D3D
rules of survival

how to compile:
https://github.com/DrNseven/Ros-D3D/blob/master/howtocompile

minhook:
https://github.com/TsudaKageyu/minhook

![alt tag](https://github.com/DrNseven/Ros-D3D/blob/master/ros.jpg)
