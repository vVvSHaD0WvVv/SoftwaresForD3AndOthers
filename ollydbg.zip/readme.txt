OllyDbg is a 32-bit code level debugger for Microsoft(R) Windows(R).
Emphasis on binary code analysis makes it particularly useful in cases
where source is unavailable. It recognizes procedures, API calls,
switches, tables, constants and strings, locates routines from object
files and libraries, allows custom labels and comments in disassembled
text, writes patches back to executable file and much, much more.

Installation is not necessary. Simply create new directory and unpack
the contents of ollydbg.zip. No installation means also no thrash in
registry and system directories. You even can start OllyDbg from the
floppy disk.

This software is a shareware and Copyright (C) 2000 Oleh Yuschuk. You
can use it and distribute FOR FREE, provided that OllyDbg remains
unchanged. Read license.txt for details.

To use this software on a permanent basis or for commercial purposes,
you must register OllyDbg by filling registration form and emailing it
to Ollydbg@t-online.de. The registration is free of charge and assumes
no financial or other obligations from both sides - just be fair and
let me know that you like this software :)

If you have questions, or to get the newest information and bugfixes,
visit OllyDbg Internet site 

     http://home.t-online.de/home/Ollydbg

Please report encountered errors and problems to

     Ollydbg@t-online.de

In general, I promise no support but will try to answer your questions.

Hope my debugger will meet your demands,


Oleh Yuschuk                                                16-Nov-2000
