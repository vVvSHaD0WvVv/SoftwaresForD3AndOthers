<?php
$mysql_server = "www.d3local.com";
$mysql_user = "root";
$mysql_password = "";
$mysql_db = "d3dev";
$compress_scripts = false;
?>