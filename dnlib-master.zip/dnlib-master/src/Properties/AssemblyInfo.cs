// dnlib: See LICENSE.txt for more info

﻿using System.Reflection;
using System.Runtime.InteropServices;

#if THREAD_SAFE
[assembly: AssemblyTitle("dnlib (thread safe)")]
#else
[assembly: AssemblyTitle("dnlib")]
#endif
[assembly: AssemblyDescription(".NET assembly reader/writer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("dnlib")]
[assembly: AssemblyCopyright("Copyright (C) 2012-2018 de4dot@gmail.com")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
