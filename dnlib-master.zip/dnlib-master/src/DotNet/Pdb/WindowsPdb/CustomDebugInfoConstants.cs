﻿// dnlib: See LICENSE.txt for more info

namespace dnlib.DotNet.Pdb.WindowsPdb {
	static class CustomDebugInfoConstants {
		public const int Version = 4;
		public const int RecordVersion = 4;
	}
}
