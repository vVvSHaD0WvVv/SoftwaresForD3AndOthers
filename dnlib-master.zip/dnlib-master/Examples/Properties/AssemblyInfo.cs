﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("dnlib.Examples")]
[assembly: AssemblyDescription("dnlib examples")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("dnlib.Examples")]
[assembly: AssemblyCopyright("Copyright (C) 2012-2014 de4dot@gmail.com")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
