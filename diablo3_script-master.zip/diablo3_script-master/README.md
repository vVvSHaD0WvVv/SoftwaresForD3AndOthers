# diablo3_script
script for diablo3, free hands

## how to use

1. install the [AutoHotKey](https://github.com/Lexikos/AutoHotkey_L)
2. change key mappings in script
2. run the script by autohotkey or compile it
