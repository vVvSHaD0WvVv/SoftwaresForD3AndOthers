
This extension shows how to do the basic things. It:

- Reads and writes settings (MySettings.cs)
- Adds a page to the options dialog box showing some of the options (MySettingsPage.cs)
- Adds options to the text editor's context menu and a Ctrl+Alt+Q keyboard shortcut (CodeCtxMenus.cs)
- Adds treeview context menus (TreeViewCtxMenus.cs)
- Adds a "_Extension" menu and menu items and a View menu command (MainMenuCommands.cs)
- Adds a button and a combobox to the toolbar (ToolBarCommands.cs)
